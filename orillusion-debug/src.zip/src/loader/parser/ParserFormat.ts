export enum ParserFormat {
    TEXT,
    BIN,
    JSON
}