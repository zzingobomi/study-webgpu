//https://github.com/KhronosGroup/glTF/tree/main/extensions/2.0/Khronos/KHR_materials_sheen

/**
 * @internal
 * @group Loader
 */
export class KHR_materials_sheen {
}
