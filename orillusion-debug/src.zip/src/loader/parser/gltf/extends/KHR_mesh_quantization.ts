//https://github.com/KhronosGroup/glTF/tree/main/extensions/2.0/Khronos/KHR_mesh_quantization

/**
 * @internal
 * @group Loader
 */
export class KHR_mesh_quantization {
}
