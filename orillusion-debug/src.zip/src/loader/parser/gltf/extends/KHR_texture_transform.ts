//https://github.com/KhronosGroup/glTF/tree/main/extensions/2.0/Khronos/KHR_texture_transform

/**
 * @internal
 * @group Loader
 */
export class KHR_texture_transform {
}
