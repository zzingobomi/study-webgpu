export class MatrixDO {
    constructor() {
    }
}
