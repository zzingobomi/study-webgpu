export enum CameraType {
    ortho,
    perspective,
    shadow,
}