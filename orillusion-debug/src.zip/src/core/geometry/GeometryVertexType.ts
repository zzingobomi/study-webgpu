
export enum GeometryVertexType {
    split,
    compose,
    compose_bin,
}