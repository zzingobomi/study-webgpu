import { GPUVertexFormat } from '../../gfx/graphics/webGpu/WebGPUConst';
/**
 * @internal
 */
export let VertexFormat = [null, GPUVertexFormat.float32, GPUVertexFormat.float32x2, GPUVertexFormat.float32x3, GPUVertexFormat.float32x4];
