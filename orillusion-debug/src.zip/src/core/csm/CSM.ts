export class CSM {
    public static readonly Cascades = 4;
}