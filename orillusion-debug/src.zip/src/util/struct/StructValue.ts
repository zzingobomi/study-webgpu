export class f32 extends Number {

}

export class i32 extends Number {

}

export class u32 extends Number {

}