export type MaterialSetting = {
    materialChannelDebug?: boolean;
    materialDebug?: boolean;
    normalYFlip?: boolean;
}