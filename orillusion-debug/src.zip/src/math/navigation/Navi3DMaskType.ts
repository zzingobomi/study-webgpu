export class Navi3DMaskType {
    public static WalkAble: number = 1;
}