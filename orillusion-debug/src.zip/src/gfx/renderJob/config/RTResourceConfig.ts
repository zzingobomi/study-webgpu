export class RTResourceConfig {
    public static colorBufferTex_NAME: string = 'colorBufferTex';
    public static positionBufferTex_NAME: string = 'positionBufferTex';
    public static normalBufferTex_NAME: string = 'normalBufferTex';
    public static materialBufferTex_NAME: string = 'materialBufferTex';
    public static zBufferTexture_NAME: string = 'zBufferTexture';
    public static zPreDepthTexture_NAME: string = 'zPreDepthTexture';
    public static outTex_NAME: string = 'outTex';
}
